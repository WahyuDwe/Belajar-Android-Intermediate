package com.dwi.dicodingstoryapp.utils

object Constanta {
    const val ACCESS_TOKEN = "access_token"
    const val STORIES_ID = "stories_id"
}