package com.dwi.dicodingstoryapp.data.source.remote

enum class StatusResponse {
    SUCCESS,
    ERROR
}